﻿using System;

namespace EmailScanner.DAL.Models
{
    /// <summary>
    /// DTO for Outlook mails
    /// </summary>
    public class OutLookMessageDAL
    {
        public int Id { get; set; }
        public DateTime MailReceivedDate { get; set; }
        public string FromEmailId { get; set; }
        public string Subject { get; set; }
        public string Body { get; set; }
        public string Recipients { get; set; }
        public string Attachments { get; set; }
        public DateTime CreatedDate { get; set; }
    }
}
