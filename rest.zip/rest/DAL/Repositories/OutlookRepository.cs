﻿using EmailScanner.DAL.DatabaseContext;
using EmailScanner.DAL.Models;
using System;
using System.Data.Entity.Core;

namespace EmailScanner.DAL.Repositories
{
    /// <summary>
    /// Repository for Outlook
    /// </summary>
    public class OutlookRepository : IOutlookRepository
    {
        private readonly DBConnContext _dbContext;

        public OutlookRepository(DBConnContext dbContext)
        {
            _dbContext = dbContext;
        }

        /// <summary>
        /// Create an entry for the mails in DB
        /// </summary>
        /// <param name="outLookMessageDAL"></param>
        /// <returns></returns>
        public int CreateMailEntry(OutLookMessageDAL outLookMessageDAL)
        {
            try
            {
                _dbContext.OutLookMessages.Add(outLookMessageDAL);
                return _dbContext.SaveChanges();
            }
            catch (EntityException exception)
            {
                throw exception;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
