﻿using EmailScanner.DAL.Models;

namespace EmailScanner.DAL.Repositories
{
    /// <summary>
    /// Interface Repository for Outlook
    /// </summary>
    public interface IOutlookRepository
    {
        int CreateMailEntry(OutLookMessageDAL outLookMessageDAL);
    }
}
