﻿using EmailScanner.DAL.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace EmailScanner.DAL.DatabaseContext
{
    /// <summary>
    /// DBContext class
    /// </summary>
    public class DBConnContext : DbContext
    {
        public DBConnContext(DbContextOptions<DBConnContext> options) : base(options)
        {
        }
        public DbSet<OutLookMessageDAL> OutLookMessages { get; set; }
        protected override void OnModelCreating
            (ModelBuilder builder)
        {
            builder.Entity<OutLookMessageDAL>(ConfigureOutLookMessagesItem);
        }

        private void ConfigureOutLookMessagesItem
       (EntityTypeBuilder<OutLookMessageDAL> builder)
        {
            builder.ToTable("OutLookMails");

            builder.Property(e => e.Id)
                   .HasColumnName("Id")
                   .UseIdentityAlwaysColumn();

            builder.Property(e => e.Subject)
                   .IsRequired()
                   .HasColumnName("Subject");

            builder.Property(e => e.FromEmailId)
                  .IsRequired()
                  .HasColumnName("FromEmailId");

            builder.Property(e => e.Body)
                  .IsRequired()
                  .HasColumnName("Body");

            builder.Property(e => e.Attachments)
                  .IsRequired()
                  .HasColumnName("Attachments");

            builder.Property(e => e.Recipients)
                  .IsRequired()
                  .HasColumnName("Recepients");

            builder.Property(e => e.MailReceivedDate)
                  .IsRequired()
                  .HasColumnName("MailReceivedDate");

            builder.Property(e => e.CreatedDate).HasColumnName("created_date").ValueGeneratedOnUpdate()
                     .Metadata.SetAfterSaveBehavior(PropertySaveBehavior.Ignore);

        }
    }
}


