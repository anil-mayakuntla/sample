﻿using AutoMapper;
using EmailScanner.DAL.Models;
using System;

namespace EmailScanner
{
    class AutomapperProfile : Profile
    {
        /// <summary>
        /// Automapper model to Dal DTO
        /// </summary>
        public AutomapperProfile()
        {
            try
            {
                CreateMap<MailModel, OutLookMessageDAL>().ReverseMap()
            .ForMember(dest => dest.OutAttachments, opt => opt.Ignore())
            .ForMember(dest => dest.Outlookrecipients, opt => opt.Ignore())
            .ForMember(dest => dest.LstRecipients, opt => opt.Ignore());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}