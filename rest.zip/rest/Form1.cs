﻿using AutoMapper;
using EmailScanner.DAL.DatabaseContext;
using EmailScanner.DAL.Repositories;
using Microsoft.EntityFrameworkCore;
using System;
using System.Configuration;
using System.Text;
using System.Windows.Forms;

namespace EmailScanner
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //Declare and Initialize
            StringBuilder data = new StringBuilder();
            int noOfDays;
            DateTime date = new DateTime();
            AutoFacInjection.Register();
            string senderName = ConfigurationManager.AppSettings["SenderName"];
            int.TryParse(ConfigurationManager.AppSettings["PrevNoOfDays"],out noOfDays);
            bool isDateAvailable = DateTime.TryParse(ConfigurationManager.AppSettings["FromDate"],out date);            
            string subject = ConfigurationManager.AppSettings["Subject"];
            string connectionstring = ConfigurationManager.ConnectionStrings["MailManagementEntities"].ConnectionString;

           
            if (!isDateAvailable)
                date= DateTime.Now;

            //Initialize the Email
            EmailScannerUtility items = new EmailScannerUtility("M1033651@mindtree.com", null, true, true, "MAPI");

            //Scan to fine the mails
            var mails = items.FindMails(subject, senderName, date, noOfDays);

            //Dependency Injection
            //DB
            var optionsBuilder = new DbContextOptionsBuilder<DBConnContext>();
            optionsBuilder.UseSqlServer(connectionstring, builder =>
            {
                builder.EnableRetryOnFailure(5, TimeSpan.FromSeconds(10), null);
            });
            DBConnContext obj = new DBConnContext(optionsBuilder.Options);

            //Repository
            IOutlookRepository outlookRepository = new OutlookRepository(obj);
            //mapper
            IMapper mapperInt = new MapperConfiguration(cfg =>
            {
                cfg.AddProfile(new AutomapperProfile());
            }).CreateMapper();

            //Utility
            OutLookMessageUtility msgUtil = new OutLookMessageUtility(outlookRepository, mapperInt);


            //Save to file or DB

            if (Convert.ToBoolean(ConfigurationManager.AppSettings["SaveToDB"]))
                msgUtil.SaveMessageToDB(mails);
            else
                msgUtil.SaveMessageToXML(mails);

        }
    }
}
