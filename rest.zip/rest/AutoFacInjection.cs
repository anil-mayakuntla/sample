﻿using Autofac;
using AutoMapper;
using EmailScanner.DAL.Repositories;
using System;

namespace EmailScanner
{
    public class AutoFacInjection
    {
        /// <summary>
        /// Register the mapper and Repository
        /// </summary>
        public static void Register()
        {
            try
            {
                var builder = new ContainerBuilder();
                var config = new MapperConfiguration(cfg =>
                {
                    cfg.AddProfile(new AutomapperProfile());
                });
                builder.RegisterInstance(config.CreateMapper()).As<IMapper>().SingleInstance();

                builder.RegisterType<OutlookRepository>().As<IOutlookRepository>().InstancePerRequest();

                var container = builder.Build();
            }            
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
