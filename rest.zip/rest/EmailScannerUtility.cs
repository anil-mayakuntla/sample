﻿using Microsoft.Office.Interop.Outlook;
using System;
using System.Collections.Generic;
using System.Reflection;
using Outlook = Microsoft.Office.Interop.Outlook;
using System.Runtime.InteropServices;
using System.Text;

namespace EmailScanner
{
    /// <summary>
    /// Email scanning class
    /// </summary>
    public class EmailScannerUtility
    {
        private Application _OutlookApplication;
        private NameSpace _OutlookNameSpace;
        private MAPIFolder _OutlookInbox;
        private Items _MailItems;
        const string PR_SMTP_ADDRESS = "http://schemas.microsoft.com/mapi/proptag/0x39FE001E";

        /// <summary>
        /// Constructor to initialize email
        /// </summary>
        /// <param name="pUsername"></param>
        /// <param name="pPassword"></param>
        /// <param name="pShowDialog"></param>
        /// <param name="pNewSession"></param>
        /// <param name="pNamespace"></param>
        public EmailScannerUtility(string pUsername, string pPassword, bool pShowDialog, bool pNewSession, string pNamespace)
        {
            try
            {
                
                _OutlookApplication = new Outlook.Application();
                Outlook.Account account = _OutlookApplication.Session.Accounts[pUsername];
                _OutlookNameSpace = _OutlookApplication.GetNamespace(pNamespace);
                object username = pUsername;
                object password = pPassword;

                if (username == null)
                {
                    username = Missing.Value;
                }
                if (password == null)
                {
                    password = Missing.Value;
                }

                //var Session = _OutlookApplication.CreateObject("Redemption.RDOSession");
                //Session.LogonExchangeMailbox(pUsername, pPassword);
                //Session.ParentWindow = SomeHWND;
                //Session.LogonHostedExchangeMailbox
                //    "user@mydomain.onmicrosoft.com", _
                //    "user@mydomain.onmicrosoft.com", _
                //    "<thePassword>";

                _OutlookNameSpace.Logon(Missing.Value, Missing.Value, false, true);

                //_OutlookNameSpace.Logon(username, password, pShowDialog, pNewSession);

                _OutlookInbox = _OutlookNameSpace.GetDefaultFolder(Outlook.OlDefaultFolders.olFolderInbox);

                _MailItems = _OutlookInbox.Items;
            }
            catch (System.Exception e)
            {
                Console.WriteLine($"{e} Exception caught");
            }
        }

        public void Disconnect()
        {
            _OutlookNameSpace.Logoff();
        }

        public void Release(object obj)
        {
            if (obj != null)
            {
                Marshal.ReleaseComObject(obj);
            }
        }

        /// <summary>
        /// Find mails based on subject,fromEmail, start date
        /// </summary>
        /// <param name="pSubject">Subject to filter</param>
        /// <param name="from">from</param>
        /// <param name="pStart">Received date</param>
        /// <param name="noOfDays">previous number of day</param>
        /// <returns></returns>
        public List<MailModel> FindMails(string pSubject, string from, DateTime? pStart, int noOfDays)
        {
            bool isFilteCriteria = false;
            DateTime? pEnd = pStart?.AddDays(-noOfDays);
            pStart = pStart?.AddDays(1);
            MailModel emailDetail;
            StringBuilder filterBuilder = new StringBuilder();
            List<MailModel> lstemailDetail = new List<MailModel>();
            try
            {
               
                filterBuilder.Append(@"@SQL=");
                if (!string.IsNullOrEmpty(pSubject))
                {
                    isFilteCriteria = true;
                    filterBuilder.Append("urn:schemas:httpmail:subject LIKE '%" + pSubject + "%' AND ");
                }

                if (!string.IsNullOrEmpty(from))
                {
                    isFilteCriteria = true;
                    filterBuilder.Append("urn:schemas:httpmail:fromname LIKE '%" + from + "%' AND ");
                }

                if (pStart != null)
                {
                    isFilteCriteria = true;
                    filterBuilder.Append("urn:schemas:httpmail:datereceived < '" +
                                           (pStart?.ToString("MM/dd/yyyy")) + "' AND " +
                                           "urn:schemas:httpmail:datereceived >= '" +
                                           (pEnd?.ToString("MM/dd/yyyy")) + "' AND ");
                }

                if (isFilteCriteria)
                {
                    string filter = Convert.ToString(filterBuilder).Remove(filterBuilder.Length - 5);

                    Outlook.Items restrictedItems = _OutlookInbox.Items.Restrict(filter);
                    foreach (MailItem item in restrictedItems)
                    {
                        emailDetail = new MailModel();
                        if (item.SenderEmailType == "EX")
                        {
                            emailDetail.FromEmailId = item.Sender.GetExchangeUser().PrimarySmtpAddress;
                        }
                        else
                        {
                            emailDetail.FromEmailId = item.SenderEmailAddress;
                        }
                        emailDetail.MailReceivedDate = item.ReceivedTime;
                        emailDetail.Subject = item.Subject;
                        emailDetail.Outlookrecipients = item.Recipients;
                        for (int i = 1; i <= emailDetail.Outlookrecipients.Count; i++)
                        {
                            PropertyAccessor pa = emailDetail.Outlookrecipients[i].PropertyAccessor;
                            emailDetail.LstRecipients.Add(pa.GetProperty(PR_SMTP_ADDRESS).ToString());
                        }
                        emailDetail.Body = item.Body;
                        emailDetail.OutAttachments = item.Attachments;
                        lstemailDetail.Add(emailDetail);
                        Release(item);
                    }
                }
                else
                {
                    throw new System.Exception("Need to specify alteast one filter to scan mails.");
                }
            }
            catch (System.Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                Release(_MailItems);
                Release(_OutlookApplication);
                Release(_OutlookInbox);
                Release(_OutlookNameSpace);
            }
            return lstemailDetail;
        }

    }
}