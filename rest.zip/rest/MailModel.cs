﻿using Microsoft.Office.Interop.Outlook;
using System;
using System.Collections.Generic;

namespace EmailScanner
{
    /// <summary>
    /// Model class for mails
    /// </summary>
    public class MailModel
    {
        public int Id;
        public DateTime MailReceivedDate;
        public string FromEmailId;
        public string Subject;
        public string Body;
        public string Recipients;
        public string Attachments;
        public DateTime CreatedDate;


        //Used in fontend      
        public Recipients Outlookrecipients;
        public Attachments OutAttachments;
        public List<string> LstRecipients = new List<string>();
    }
}
