﻿using AutoMapper;
using EmailScanner.DAL.Models;
using EmailScanner.DAL.Repositories;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Text;
using System.Xml;

namespace EmailScanner
{
    /// <summary>
    /// Class to Save the mails to XML or DB
    /// </summary>
    public class OutLookMessageUtility
    {
        private readonly IOutlookRepository _outlookRepository;
        private readonly IMapper _mapper;

        public OutLookMessageUtility(IOutlookRepository outlookRepository, IMapper mapper)
        {
            _outlookRepository = outlookRepository;
            _mapper = mapper;
        }

        /// <summary>
        /// Save message to XML
        /// </summary>
        /// <param name="outlookMessages">outloook Messages</param>
        public void SaveMessageToXML(List<MailModel> outlookMessages)
        {
            string destinationDirectory = Convert.ToString(ConfigurationManager.AppSettings["AttachmentsPath"]);

            XmlDocument xmlDefault = new XmlDocument();
            StringBuilder stringBuilder = new StringBuilder();
            try
            {
                stringBuilder.Append("<Outlook></Outlook>");
                XmlWriter xmlWriter = new XmlTextWriter(new StringWriter(stringBuilder));
                xmlDefault.Load(new StringReader(stringBuilder.ToString()));
                XmlNodeList xnResList = xmlDefault.SelectNodes("/Outlook");
                XmlNode xnRs = xnResList[0];

                //Iterating the mails
                foreach (MailModel outLookMessage in outlookMessages)
                {
                    XmlElement messageNode = xmlDefault.CreateElement("Message");
                    xnRs.AppendChild(messageNode);
                    XmlElement receivedDateNode = xmlDefault.CreateElement("ReceivedDate");
                    messageNode.AppendChild(receivedDateNode);

                    receivedDateNode.InnerText = outLookMessage.MailReceivedDate.ToString();
                    XmlElement fromEmailIdNode = xmlDefault.CreateElement("FromEmailId");
                    messageNode.AppendChild(fromEmailIdNode);
                    fromEmailIdNode.InnerText = outLookMessage.FromEmailId;

                    //Iterating the recepient List
                    for (int j = 0; j < outLookMessage.LstRecipients.Count; j++)
                    {
                        XmlElement toEmailIdNode = xmlDefault.CreateElement("ToEmailId");
                        messageNode.AppendChild(toEmailIdNode);
                        toEmailIdNode.InnerText = outLookMessage.LstRecipients[j];
                    }

                    XmlElement subjectNode = xmlDefault.CreateElement("Subject");
                    messageNode.AppendChild(subjectNode);
                    subjectNode.InnerText = outLookMessage.Subject;

                    XmlElement bodyNode = xmlDefault.CreateElement("Body");
                    messageNode.AppendChild(bodyNode);
                    bodyNode.InnerText = outLookMessage.Body;

                    //Iterating the attachments
                    for (int i = 1; i <= outLookMessage.OutAttachments.Count; i++)
                    {
                        string filePath = Path.Combine(destinationDirectory, outLookMessage.OutAttachments[i].FileName);
                        outLookMessage.OutAttachments[i].SaveAsFile(filePath);
                        XmlElement attachmentNode = xmlDefault.CreateElement("Attachment");
                        messageNode.AppendChild(attachmentNode);
                        messageNode.SetAttribute("id", Convert.ToString(i));
                        attachmentNode.InnerText = filePath;
                    }
                }

                //Save XML to path
                xmlDefault.Save(Convert.ToString(ConfigurationManager.AppSettings["XMLPath"]));
            }
            catch (System.Exception ex)
            {
                Console.WriteLine(ex.Message);
            }         
            finally
            {
                stringBuilder.Clear();
            }
        }

        /// <summary>
        /// Save to Db
        /// </summary>
        /// <param name="outlookMessages"> Outlook messages</param>
        public void SaveMessageToDB(List<MailModel> outlookMessages)
        {
            StringBuilder filePath = new StringBuilder();
            StringBuilder recepient = new StringBuilder();
            string attachmentPath = string.Empty;
            string destinationDirectory = Convert.ToString(ConfigurationManager.AppSettings["AttachmentsPath"]);

            try
            {
                foreach (MailModel outLookMessage in outlookMessages)
                {
                    //Appending recepients
                    for (int j = 0; j < outLookMessage.LstRecipients.Count; j++)
                    {
                        recepient.Append(outLookMessage.LstRecipients[j] + ",");
                    }

                    //Appending attachement file path
                    for (int i = 1; i <= outLookMessage.OutAttachments.Count; i++)
                    {
                        attachmentPath = Path.Combine(destinationDirectory, outLookMessage.OutAttachments[i].FileName);
                        outLookMessage.OutAttachments[i].SaveAsFile(attachmentPath);
                        filePath.Append(
                        Path.Combine(destinationDirectory, outLookMessage.OutAttachments[i].FileName + ","));
                    }

                    outLookMessage.Recipients = Convert.ToString(recepient).TrimEnd(',');
                    outLookMessage.Attachments = Convert.ToString(filePath).TrimEnd(',');
                    outLookMessage.CreatedDate = DateTime.Now;

                    var mailMapperResult = _mapper.Map<OutLookMessageDAL>(outLookMessage);

                    //call to repository to save to DB
                    _outlookRepository.CreateMailEntry(mailMapperResult);

                    filePath.Clear();
                    recepient.Clear();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                filePath.Clear();
                recepient.Clear();
            }
        }
    }
}
