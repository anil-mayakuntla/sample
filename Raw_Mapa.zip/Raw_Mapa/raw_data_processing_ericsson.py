import pandas as pd


df1 = pd.read_csv('./ericsson/input/2G_RAW_0020.csv')
df2 = pd.read_csv('./ericsson/input/2G_RAW_2123.csv')

res = pd.concat([df1, df2])
res1 = df1

df3 = pd.read_csv('./support/SiteDB_2G_CH_17-08-2020.csv')
df3 = df3[['OSS_Cell_ID-Name', 'HQ_TOWN', 'Net_TRXs_Available', 'Total_TS_Available', 'BCCH', 'NOOFSDCCH', 'FPDCH', 'TCH_Available_For_Voice', 'Equipped_Erlang_Capacity_forVoice', 'SitePreference', 'REGION', 'CI-Name', 'Active_1800_TRX', 'Vendor', 'roaming_inroaming', 'Acceptance_Status']]

df3 = df3.rename(columns={'OSS_Cell_ID-Name':'SCE name'})

res2 = pd.merge(res1, df3, how='left', on='SCE name')
