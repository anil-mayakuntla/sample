import pandas as pd
from sqlalchemy import create_engine


def input_format(input_path):
    df = pd.read_csv(input_path)
    df['Result Time'] = pd.to_datetime(df['Result Time']).dt.strftime('%d-%m-%Y %H:%M')
    df[['Date', 'Hour']] = df['Result Time'].str.split(' ', expand=True)
    df['Object Name'] = df['Object Name'].str.replace('/Cell:', '/GCELL:', regex=False)
    df['BSC'] = df['Object Name'].str.split('/', expand=True)[0]
    df['Cell Name'] = df['Object Name'].str.split(',', expand=True)[0].str.split('=', expand=True)[1]
    return df


huawei1 = input_format('./huawei/input/GDC_NPM_2G_Hourly_1.csv')
huawei2 = input_format('./huawei/input/GDC_NPM_2G_Hourly_2.csv')
huawei3 = input_format('./huawei/input/GDC_NPM_2G_Hourly_3.csv')
huawei3['TRX_Raw'] = huawei3['Object Name'].str.split('/', expand=True)[2]
huawei3['Object Name'] = (huawei3['Object Name'].str.split('/', expand=True)[0]+'/'+huawei3['Object Name'].str.split('/', expand=True)[1])[0]
huawei4 = input_format('./huawei/input/GDC_NPM_2G_Hourly_4.csv')

cols = []
for col in huawei1.columns:
    if col in huawei2.columns and col in huawei3.columns and col in huawei4.columns:
        cols.append(col)

res1 = pd.merge(huawei1, pd.merge(huawei2, pd.merge(huawei3, huawei4, how='outer', on=cols), how='outer', on=cols), how='outer', on=cols).fillna(0)

sitedb1 = pd.read_csv('./support/SiteDB_2G_CH_17-08-2020.csv')
sitedb1 = sitedb1[['OSS_Cell_ID-Name', 'HQ_TOWN', 'SitePreference', 'REGION', 'Vendor', 'Acceptance_Status']]
sitedb1 = sitedb1.rename(columns = {'OSS_Cell_ID-Name' : 'Cell Name'})

res2 = pd.merge(res1, sitedb1, how='left', on=['Cell Name']).fillna(0)


# Ericsson raw data processing

ericsson1 = pd.read_csv('/ericsson/input/2G_RAW_0020.csv')
ericsson2 = pd.read_csv('/ericsson/input/2G_RAW_2123.csv')

res3 = pd.concat(ericsson1, ericsson2)
res3 = res3.ren

# header_low=[]
# for col in res2.columns:
#     header_low.append(col.lower().replace(' ','_').replace('(','_').replace(')','').replace('__','_').replace('-', '_'))
#
# res2.columns = header_low
#
# temp1 = res2.copy().reset_index()
# temp2 = temp1[['index', 'cell_name', 'total_traffic_erlangs']].groupby('cell_name').aggregate(max)
# all_bbh = res2.iloc[(temp2.reset_index())['index']]
#
# temp2 = temp1[['index', 'cell_name', 'tot_vol_data_downloaded']].groupby('cell_name').aggregate(max)
# gprs_bbh = res2.iloc[(temp2.reset_index())['index']]
#
# all_nbh = temp1.loc[temp1['hour'] == (temp1[temp1.total_traffic_erlangs == temp1.total_traffic_erlangs.max()])['hour'].values[0]]
# all_nbh = all_nbh.drop(columns=['index'])
#
# # needs to be calculated based on the aggregation criteria which Preeti will provide
# # all_daily =
#
# # print(all_bbh.to_string(index=False))
# # print(gprs_bbh.to_string(index=False))
#
# # res2.to_csv('./huawei/output/gdc_npm_2g_hourly_huawei.csv', index=False)
# # engine = create_engine('postgresql://TestUser:test1234@localhost:5432/mapa')
# # res2.to_sql('huawei_raw_2g', engine)
#
