

--Create the DB Mails 
CREATE DATABASE [Mails];

--Create the table OutLookMails
USE [Mails]
GO
CREATE TABLE [dbo].[OutLookMails] (
    [Id]               INT IDENTITY(1,1) PRIMARY KEY,
    [Subject]          NVARCHAR (50)  NULL,
    [FromEmailId]      NVARCHAR (MAX) NULL,
    [Body]             NVARCHAR (MAX) NULL,
    [Attachments]      NVARCHAR (MAX) NULL,
    [Recepients]       NVARCHAR (MAX) NULL,
    [MailReceivedDate] DATETIME2 (7)  NULL,
    [created_date]     DATETIME2 (7)  NULL
);

----Connection string in app.config should be modified.
--- appsetting need to be configured as per requirement.

--Destination folder to be created for 
1.XMLPath
2.AttachmentsPath


Follwing appsetting keys can be updated as per requiremnt
    <add key="Subject" value=".Net" /> -- Will perform Like search
    <add key="SenderName" value="Manoranjini" /> -- Will perform Like search
    <add key="FromDate" value="10/16/2020" />
    <add key="PrevNoOfDays" value="1" />

---Save to DB or XML (If DB set to true else if XML set to false)
 <add key="SaveToDB" value="True" />

